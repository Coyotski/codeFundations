//interface fantastico
public interface Fantastico {
    void volar();
    void petrificarse();
    void comer(String almaEnPena);    // comportamiento mágico
    boolean morir(String ritual);     // muerte mágica
    
}
