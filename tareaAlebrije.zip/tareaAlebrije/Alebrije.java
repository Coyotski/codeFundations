//clase Alebrije que implementa la interfaz Fantastico
public class Alebrije extends Animal implements Fantastico {

    private String color;
    private String forma;
    private int patas;

    public Alebrije(String nombre, String especie, int edad, double peso,
                    String color, String forma, int patas) {
        super(nombre, especie, edad, peso);
        this.color = color;
        this.forma = forma;
        this.patas = patas;
    }

    @Override
    public void volar() {
        System.out.println(nombre + " está volando en una noche de luna nueva.");
    }

    @Override
    public void petrificarse() {
        System.out.println(nombre + " se está petrificando por causas mágicas.");
    }

    // Sobrecarga adicional
    public void petrificarse(String motivo) {
        System.out.println(nombre + " se ha petrificado debido a " + motivo + ".");
        this.forma = motivo;
    }

    @Override
    public void comer(String almaEnPena) {
        System.out.println(nombre + " está comiendo el alma en pena de " + almaEnPena + ".");
    }

    @Override
    public boolean morir(String ritual) {
        System.out.println(nombre + " ha muerto tras el ritual de " + ritual + " y se ha convertido en cenizas.");
        return true;
    }

    @Override
    public void comer() {
        System.out.println(nombre + " está comiendo almas.");
    }

    @Override
    public boolean morir() {
        System.out.println(nombre + " ha muerto y se ha convertido en cenizas.");
        return true;
    }
}